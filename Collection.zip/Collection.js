
;(function(){

    "use strict";
    
    var environment = this;
    var previousstd = environment.std;

    if(typeof exports != 'undefined'){
        if(typeof module != 'undefined' && module.exports ){
            exports = module.exports = std;
        }
    }
    else{
        environment.std = std;
    };

    //AMD的支持
    if (typeof define === 'function' && define.amd) {
		define('std', [], function() {
			return std;
		});
    }

    function std(){}
    std.version = '1.0.0';
    std.printf = console.log;
    
    //交出std的控制权给其他的库
    std.noConflict = function(){
        environment.std = previousstd;
        return this;
    }
    
    //挂载到std对象上面
    std.linkedList = linkedList;
    std.stack = stack;
    std.queue = queue;
    std.hashMap = hashMap;
    std.binarySearchTree = AVLTree;

    //原型对象的处理
    var linkedListProto = linkedList.prototype;
    var stackProto = stack.prototype;
    var queueProto = queue.prototype;
    var hashMapProto = hashMap.prototype;
    var AVLTreeProto = AVLTree.prototype;

    // linkedList  data structure
    function linkedList(){
        this._headPointer = null;
        this._endPointer = null;
        this._currentPointer = null;
        this._size = 0;
        this._split = ',';
        if(!(this instanceof linkedList)){
            return new linkedList();
        }
    }

    linkedListProto._createNode = function(value){
        function Node(value){
            this.value = value;
            this.next = null;
        }
        return new Node(value);
    };

    //public方法  用来向链表中添加元素
    linkedListProto.add = function(value){
        if(!this._headPointer){
            this._headPointer = this._endPointer = this._createNode(value);
        }
        else{
            //尾指针移动到最后
            this._endPointer.next = this._createNode(value);
            this._endPointer = this._endPointer.next;
        }
        //增加size
        this._size++;

        return this;
    }

    //public方法 用来删除链表中元素
    linkedListProto.delete = function(value){
        var preNode = null;
        var currentPointer  = this._headPointer;
        //链表为空的时候
        if(!currentPointer){
            return this;
        }
        //链表中存在元素
        while(currentPointer){
            if(currentPointer.value === value){
                //链表中存在多个元素且与头节点相同，与尾节点不同
                if(currentPointer === this._headPointer && currentPointer !== this._endPointer){
                    var deletePointer = currentPointer;
                    this._headPointer = this._headPointer.next;
                    currentPointer = this._headPointer;
                    deletePointer.next = null;
                    deletePointer = null;
                    this._size--;
                }
                //链表中只存在一个节点
                else if(currentPointer === this._headPointer && currentPointer === this._endPointer){
                    this._headPointer = this._endPointer = null;
                    currentPointer = null;
                    this._size--;
                }
                //链表中存在多个元素且与尾节点相同，与头结点不同
                else if(currentPointer === this._endPointer && currentPointer !== this._headPointer){
                    var deletePointer = currentPointer;
                    this._endPointer = preNode;
                    //清除和即将删除的元素之间的next的联系
                    this._endPointer.next = null;
                    deletePointer.next = null;
                    deletePointer = null;
                    currentPointer = null;
                    this._size--;
                }
                //链表中存在多个元素，并且与头部和尾部都不同
                else if(currentPointer !== this._headPointer && currentPointer !== this._endPointer){
                    var deletePointer = currentPointer;
                    preNode.next = currentPointer.next;
                    currentPointer = currentPointer.next;
                    deletePointer.next = null;
                    deletePointer = null;
                    this._size--;
                }
            }
            else{
                preNode = currentPointer;
                currentPointer = currentPointer.next;
            }
        }
        return this;
    };

    linkedListProto.reverse = function(){
        var preNode = null;
        var currentPointer = this._headPointer;
        var nextPointer = null;
        if(!currentPointer){
            return this;
        }
        //单节点禁止反转
        if(this._headPointer === this._endPointer){
            return this;
        }
        while(currentPointer){
            //到达endPointer头尾指针切换
            if(currentPointer === this._endPointer){
                currentPointer.next = preNode;
                var saveHeadPointer = this._headPointer;
                this._headPointer = this._endPointer;
                this._endPointer = saveHeadPointer;
                return this;
            }
            //指针依次向后移动 nextPointer为endPointer的时候 切换头尾指针 
            nextPointer = currentPointer.next;
            currentPointer.next = preNode;
            preNode = currentPointer;
            currentPointer = nextPointer;
        }
    }

    linkedListProto.insertFirst  = function(value){
        var currentPointer = this._headPointer;
        //链表当前没有储存元素 直接调用add方法进行存储
        if(!currentPointer){
            this.add(value);
            return this;
        }
        //链表只有一个元素时候 移动头指针
        if(this._headPointer === this._endPointer){
            var createNode = this._createNode(value);
            createNode.next = this._endPointer;
            this._headPointer = createNode;
            this._size++;
            return this;
        }
        //链表有多个元素
        else{
            var createNode = this._createNode(value);
            createNode.next = this._headPointer;
            this._headPointer = createNode;
            this._size++;
            return this;
        }
    }

    //修改表中所有的元素
    linkedListProto.replaceAll = function(element,replaceValue){
        this.forEach(function(value){
            if(element === value){
                return replaceValue;
            }
        })

        return this;
    }
    
    //修改链表中的元素 根据索引值 只会修改指定索引处的元素
    linkedListProto.modifyElement = function(index,value){
        var currentIndex = 0;
        var currentPointer = this._headPointer;
        if(index < 0 || index > this._size -1){
            return this;
        }
        while(currentPointer){
            if(currentIndex === index){
                currentPointer.value = value;
                return this;
            }
            currentPointer = currentPointer.next;
            currentIndex++;
        }
        return this;
    }

    //将元素插入到指定的位置上 索引从0开始
    linkedListProto.insertBefore = function(index,value){
        var currentIndex = 0;
        var currentPointer = this._headPointer;
        var preNode = null;
        if(index === undefined || value === undefined || index < 0){
            return this;
        }
        if(index > this._size-1){
            this.add(value);
            return this;
        }
        while(currentPointer){
            if(currentIndex === index){
                //插入的索引的位置为0
                if(currentPointer === this._headPointer){
                    this.insertFirst(value);
                    return this;
                }
                else{
                    var createNode = this.createNode(value);
                    preNode.next = createNode;
                    createNode.next = currentPointer;
                    this._size++;
                    return this;
                }
            }
            else{
                currentIndex++;
                preNode = currentPointer;
                currentPointer = currentPointer.next;
            }
        }
        return this;
    };

    //按插入的顺序查找元素在表中的位置
    linkedListProto.indexOf = function(value){
        var position = -1;
        var index = 0;
        var currentPointer = this._headPointer;
        if(!currentPointer){
            return position;
        }
        while(currentPointer){
            if(currentPointer.value === value){
                position = index;
                return position;
            }
            currentPointer = currentPointer.next;
            index++;
        }
        return position;
    };

    //按序找到元素在表中最后一次出现的位置
    linkedListProto.lastIndexOf = function(value){
        var lastPosition = -1;
        var index = 0;
        var currentPointer = this._headPointer;
        if(!currentPointer){
            return lastPosition;
        }
        while(currentPointer){
            if(currentPointer.value === value){
                lastPosition = index;
            }
            currentPointer = currentPointer.next;
            index++;
        }
        return lastPosition;
    };

    //按序查找 返回相应索引位置的元素
    linkedListProto.find = function(index){
        var currentIndex = 0;
        var currentPointer = this._headPointer;
        if(index < 0 || index > this._size -1){
            return -1;
        }
        while(currentPointer){
            if(currentIndex === index){
                return currentPointer.value;
            }
            currentPointer = currentPointer.next;
            currentIndex++;
        }
        return -1;
    };

    //按序查找 遍历元素 如果需要改变值 callback中直接将值返回
    linkedListProto.forEach = function(callback){
        var currentPointer = this._headPointer;
        var index = -1;
        while(currentPointer){
            index++;
            var value = currentPointer.value;
            var modifyValue = callback(value,index,currentPointer);
            //如果用户需要改变值 直接返回即可
            modifyValue ? currentPointer.value = modifyValue : '';
            currentPointer = currentPointer.next;
        }
        return this;
    };

    //输出链表
    linkedListProto.toString = function(){
        var that = this;
        var string = '';
        this.forEach(function(value,index){
            string = string.concat(value,that._split);
        })
        std.printf(string);
        return this;
    };


    // stack  data structure
    function stack(stackSize){
        //如果传入了stackSize，栈的容量就会限制为stackSize的大小 否则无限制
        this._size = 0;
        this._stackArray = null;
        this._pointer  = -1;
        this._stackSize = stackSize != undefined ? stackSize : -1;
        this._split = ',';

        if(!(this instanceof stack)){
            return new stack(stackSize);
        }
    }

    stackProto._initStackArray = function(){
        this._stackArray = new Array();
    };

    stackProto.push =  function(value){
        if(!this._stackArray){
            this._initStackArray();
        }
        //_stackSize大于0表示限制了栈的大小
        if(this._stackSize >= 0){
            if(this._size < this._stackSize){
                this._stackArray[++this._pointer] = value;
                this._size++;
            }
            else{
                std.printf('std Warning:  stack容量被限制了大小,栈空间已满!');
            }
            return this;
        }
        //没有限制栈的大小 直接插入
        else{
            this._stackArray[++this._pointer] = value;
            this._size++;
        }
        return this;
    }

    stackProto.pop = function(){
        //栈空则直接返回
        if(this.isEmpty()){
            std.printf('std Warning:  stack容量为0,栈为空!');
            return this;
        }
        this._stackArray[this._pointer--] = undefined;
        this._size--;

        return this;
    };

    stackProto.popUntil = function(value){
        //栈空则直接返回
        if(this.isEmpty()){
            std.printf('std Warning:  stack容量为0,栈为空!');
            return this;
        }
        //栈中不存在元素直接返回
        if(!this.contains(value)){
            return this;
        }
        while(this.peek() != value){
            this.pop();
        }

        return this;
    };

    stackProto.popUtilWithString = function(value){
        var that = this;
        var string = '';
        //栈空则直接返回
        if(this.isEmpty()){
            std.printf('std Warning:  stack容量为0,栈为空!');
            return string;
        }
        //栈中不存在元素直接返回
        if(!this.contains(value)){
            return string;
        }
        while(this.peek() != value){
            string = string.concat(that.peek());
            this.pop();
        }

        return string;
    }

    stackProto.peek = function(){
        //栈空则直接返回
        if(this.isEmpty()){
            return '';
        }

        return this._stackArray[this._pointer];
    };

    stackProto.contains = function(value){
        //栈空则直接返回
        if(this.isEmpty()){
            return this;
        }
        var find = false;
        for(var index = 0 ; index < this._size-1 ; index++){
            if(this._stackArray[index] === value){
                find = true;
                break;
            }
        }

        return find;
    };

    stackProto.popAllWithString = function(boolean){
        var that = this;
        var string = '';
        //栈空则直接返回
        if(this.isEmpty()){
            return this;
        }
        while(!that.isEmpty()){
            string = string.concat(that.peek());
            that.pop();
        }
        //boolean为true的时候表示要反转字符串
        boolean = boolean != undefined ? boolean : false;
        if(boolean){
            string = string.split("").reverse().join("");          
        }

        return string;
    }

    stackProto.makeEmpty = function(){
        //栈空则直接返回
        if(this.isEmpty()){
            return this;
        }

        while(!this.isEmpty()){
            this.pop();
        }

        return this;
    };

    stackProto.isEmpty = function(){
        return !this._size;
    }

    stackProto.toString = function(){
        var that = this;
        var string = '';
        //栈空则直接返回
        if(this.isEmpty()){
            return this;
        }

        for(var index = 0 ; index <= this._pointer ; index++){
            string = string.concat(that._stackArray[index],that._split);
        }
        std.printf(string);
        string = null;

        return this;
    };

    // queue  data structure
    function queue(queueSize){
        if(!(this instanceof queue)){
            return new queue(queueSize);
        }
        this._array = null;
        this._size = 0;
        this._front = 0;
        this._rear = 0;
        this.split = '-';
        this._queueSize = queueSize && queueSize > 0 ? queueSize : 1000;
    }
    
    queueProto._initArray = function(){
        var that = this;
        this._array = new Array(that._queueSize);
    }
    
    queueProto.enqueue = function(value){
        if(!this._array){
            this._initArray();
        }
        if(this._size === this._queueSize){
            std.printf('std Warning:  queue的空间已满!');
            return this;
        }
        this._array[(this._rear++) % this._queueSize] = value;
        this._size++;
    }

    queueProto.dequeue = function(){
        if(this.isEmpty()){
            std.printf('std Warning:  queue的空间已空!');
            return this;
        }

        this._array[(this._front++) % this._queueSize] = undefined;
        this._size--;
    }

    queueProto.makeEmpty = function(){
        while(!this.isEmpty()){
            this.dequeue();
        }
    }

    //获取当前队首的元素
    queueProto.peek = function(){
        if(this.isEmpty()){
            return '';
        }

        return this._array[this._front];
    }

    queueProto.dequeueAllWithString = function(){
        var that = this;
        var string = '';
        while(!that.isEmpty()){
            string = string.concat(that.peek());
            that.dequeue();
        }
        return string;
    }

    queueProto.isEmpty = function(){
        return !this._size;
    }

    queueProto.toString = function(){
        var front = this._front;
        var rear = this._rear;
        var array = this._array;
        var split = this.split;
        //递归输出
        function toString(front,array){
            if(front < rear){
                var string = array[front] + split + (toString(++front,array));
                return string;
            }
            return '';
        }

        std.printf(toString(front,array));
    }

    // hashMap  data structure
    function hashMap(){
        this._hashArray = null;
        this._arraySize = 1009;
        this._size = 0;
        this._reHashGrow = 2;
        this._hashFactor = 0.7;
        if(!(this instanceof hashMap)){
            return new hashMap();
        }
    }

    hashMapProto.initHashArray = function(){
        var that = this;
        this._hashArray =  new Array(that._arraySize);
    }

    hashMapProto.createEntry = function(key,value){
        //内部类
        function Entry(key,value){
            this._key  = key;
            this._value = value;
            this._isEmpty = false;
        }
        Entry.prototype.isEmpty = function(){
            return this._isEmpty;
        }
        Entry.prototype.delete = function(){
            this._isEmpty = true;
        }
        return new Entry(key,value);        
    }

    hashMapProto.hashValue = function(atom){
        //Object转换为字符串
        var string = '';
        if(atom instanceof Object){
            //jsonParse可能会报错
            try{
                string = JSON.stringify(atom);
            }catch(err){
                std.printf('std Warning:  HashValue函数处理出错 key为一个无法转换为字符串的Json对象!');
            }
        }
        else{
            string = String(atom);
        }
        //返回根据对象计算值
        return getHashValue(string);
        //递归累计CharCode
        function getHashValue(string){
            if(!string){
                return 0;
            }
            return summation(string.charCodeAt(0) , getHashValue(string.substring(1)));
        }
    
        function summation(num , nums){
            return num + nums;
        }
    }

    hashMapProto.hashAddress = function(key){
        var hashValue = this.hashValue(key);
        var hashAddress = hashValue % this._arraySize;

        return hashAddress;
    }

    //找到大于当前baseNumber的最小素数 保证散列的效果
    hashMapProto.primeNumber = function(baseNumber){
        while(baseNumber){
            for(var index = 2 ; index < baseNumber ; index++){
                if(baseNumber % index === 0){
                    baseNumber ++;
                    break;
                }
            }
            if(index === baseNumber){
                break;
            }
        }
        return baseNumber;
    }

    hashMapProto.put = function(key,value){
        if(!this._hashArray){
            this.initHashArray();
        }

        //检查当前hash表的容量 容量不足时候进行再散列
        if(this.gethashFactor() > this._hashFactor){
            this.reHashOperation();
        }

        var that = this;
        var hashArray = this._hashArray;
        var hashAddress = this.hashAddress(key);
        var createEntry = this.createEntry;

        //储存元素到制定的hash位置
        while(true){
            if(putElement(hashArray,hashAddress,key,value)){
                break;
            }
            hashAddress++;
        }

        function putElement(hashArray,hashAddress,key,value){
            //hash表当前没被占用
            if(!hashArray[hashAddress]){
                hashArray[hashAddress] = createEntry(key,value);
                that._size++;
                return true;
            }
            else{
                //元素被惰性删除
                var entry = hashArray[hashAddress];
                if(entry.isEmpty()){
                    entry._key = key;
                    entry._value = value;
                    entry._isEmpty = false;
                    that._size++;
                    return true;
                }
                //插入两个相同的key值 此时发生元素的覆盖
                else if(entry._key === key){
                    entry._value = value;
                    return true;
                }
            }
        }
    }

    hashMapProto.delete = function(key){
        var hashArray = this._hashArray;
        var hashAddress = this.hashAddress(key);
        deleteElement(hashAddress,hashArray,key);

        function deleteElement(hashAddress,hashArray,key){
            if(hashArray[hashAddress]){
                var entry = hashArray[hashAddress];
                if(entry._key === key){
                    entry._isEmpty = true;
                    return;
                }
            }
            deleteElement(++hashAddress,hashArray,key);
        }
    }

    hashMapProto.get = function(key){
        var hashArray = this._hashArray;
        var hashAddress = this.hashAddress(key);
        var maxPosition = this._arraySize;

        if(!hashArray){
            return false;
        }

        //递归的获取元素
        return getElement(hashArray,hashAddress,maxPosition,key);

        function getElement(hashArray,hashAddress,maxPosition,key){
            //超出hash表的范围
            if(hashAddress > maxPosition){
                return false;
            }
            if(hashArray[hashAddress]){
                var entry = hashArray[hashAddress];
                if(entry._key === key){
                    if(entry.isEmpty()){
                        return;
                    }
                    return entry._value;
                }
            }
            //递归向后查找
            return getElement(hashArray,++hashAddress,maxPosition,key);
        }
    }

    hashMapProto.gethashFactor = function(){
        return (this._size / this._arraySize).toFixed(3);
    }

    hashMapProto.reHashOperation = function(){
        var that = this;

        //hash因子大于设定的值时候进行再散列
        if(that.gethashFactor() > that._hashFactor){
            //储存Hash表
            var usedHashArray = that._hashArray;
            //保证hashArray是一个素数
            that._size = 0;
            that._arraySize = that.primeNumber(that._arraySize*that._reHashGrow);
            that._hashArray = new Array(that._arraySize);
            var freshHashArray = that._hashArray;
            var index = 0;
            console.log('正在再散列操作  新散列表的长度为'+this._arraySize);
            //清除内存空间
            for(var index = 0 ; index < usedHashArray.length ; index++){
                copyHashArray(index,usedHashArray,freshHashArray);
            }

            function copyHashArray(index,usedHashArray,freshHashArray){
                if(usedHashArray[index]){
                    var entry = usedHashArray[index];
                    if(!entry.isEmpty()){
                        var key = entry._key;
                        var value = entry._value;
                        that.put(key,value);
                    }
                }
                usedHashArray[index] = null;
            }
        }
    }

    // AVLTree  data structure
    function AVLTree(boolean){
        this._rootNode = null;
        this._unbalanceFactor = 1;
        this.autoAdjust = boolean != undefined ? boolean : true;
        if(!(this instanceof AVLTree)){
            return new AVLTree(boolean);
        }
    }

    AVLTreeProto._createNode = function(value){
        function Node(value){
            this.value = value;
            this._leftChild = null;
            this._rightChild = null;
            //[left|right]当一个节点失衡的时候 这个值代表的是左子树失衡还是右子树失衡
            this._unBalanceDirection = "";
        }
        return new Node(value);
    }

    //这个方法在插入元素的时候自动调整树的平衡性
    AVLTreeProto.put = function(element){
        var that = this;
        var createNode  = that._createNode;
        //引入sort函数进行排序
        var sort = that.sort;
        that._rootNode = insertData(that._rootNode,element);
        function insertData(treeNode,element){
            if(!treeNode){
                treeNode = createNode(element);
            }
            else{
                //新插入的元素比当前的元素大
                if(sort(treeNode.value,element) > 0){
                    treeNode._rightChild = insertData(treeNode._rightChild,element);
                }
                else if(sort(treeNode.value,element) <0){
                    treeNode._leftChild = insertData(treeNode._leftChild,element);
                }
                //两个元素相等 此时覆盖元素
                else{
                    treeNode.value = element;
                }
            }
            return treeNode;
        }
        //默认是设置自动调整平衡性可以在构造函数中传入boolean为false来关闭
        that.autoAdjustBalance();
        return this;
    }

    AVLTreeProto.delete = function(key){
        var that = this;
        var deleteNode = that.find(key);
        deleteOperation(deleteNode);
        function deleteOperation(deleteNode){
            //删除的节点当前搜索树中不存在时候 直接返回
            if(!deleteNode){
                return this;
            }
            //待删除的节点为叶子节点
            if(!deleteNode._leftChild && !deleteNode._rightChild){
                that._replacePointer(deleteNode,null);
            }
            //待删除的节点仅有一个左孩子节点
            else if(deleteNode._leftChild && !deleteNode._rightChild){
                that._replacePointer(deleteNode,deleteNode._leftChild);
            }
            //待删除的节点仅有一个右盖子节点
            else if(!deleteNode._leftChild && deleteNode._rightChild){
                that._replacePointer(deleteNode,deleteNode._rightChild);
            }
            //待删除的节点左右孩子节点全部存在
            else{
                //寻找右子树的最小左子树
                var minTreeNode = that._findMin(deleteNode._rightChild);
                //交换元素的值 并且删除右子树的最小元素
                deleteNode.value = minTreeNode.value;
                //删除右子树的最小左子树
                that._replacePointer(minTreeNode,null);
            }
        }
        //默认是设置自动调整平衡性可以在构造函数中传入boolean为false来关闭
        that.autoAdjustBalance();
        return this;
    }

    AVLTreeProto.contains = function(key){
        var that = this;
        return Boolean(that.find(key));
    }

     //引用类型不能直接操作堆内存中的变量
     AVLTreeProto._replacePointer = function(pointer,address){
         var that = this;
         //如果操作的是rootNode，直接堆rootNode赋值
         if(pointer == that._rootNode){
             that._rootNode = address;
         }
         //操作的是普通的node对象
         else{
             var parent = that._parent(pointer);
             if(parent._leftChild == pointer){
                parent._leftChild = address;
             }
             else{
                parent._rightChild = address;
             }
         }
    }

    AVLTreeProto._findMin = function(node){
        if(!node){
            return null;
        }
        return findMin(node);
        function findMin(treeNode){
            if(!treeNode._leftChild){
                return treeNode;
            }
            return findMin(treeNode._leftChild);
        }
    }

    AVLTreeProto._parent = function(treeNode){
        var that = this;
        var parent = null;
        var node = that._rootNode;
        if(!treeNode){
            return null;
        }
        //rootNode节点 直接返回节点本身
        if(treeNode === that._rootNode){
            return treeNode;
        }
        //一般节点 返回其父节点
        while(node && node.value !== treeNode.value){
            if(node.value > treeNode.value){
                parent = node;
                node = node._leftChild;
            }
            else{
                parent = node;
                node = node._rightChild;
            }
        }
        return parent;
    }

    //sort(existsElement,insertElement)返回大于0的数 表示新插入的元素的值大
    AVLTreeProto.find = function(key){
        var that = this;
        return find(that._rootNode,key);
        function find(treeNode,key){
            if(!treeNode){
                return null;
            }
            else if(that.sort(treeNode.value,key) == 0){
                return treeNode;
            }
            else{
                if(that.sort(treeNode.value,key) < 0){
                    return find(treeNode._leftChild,key);
                }
                else{
                    return find(treeNode._rightChild,key);
                }
            }
        }
    }

    //降序遍历
    AVLTreeProto.descEach = function(callback){
        var that = this;
        traverse(that._rootNode,callback);
        function traverse(treeNode,callback){
            if(!treeNode){
                return;
            }
            else{
                traverse(treeNode._rightChild,callback);
                callback(treeNode.value);
                traverse(treeNode._leftChild,callback);
            }
        }
    }

    //升序遍历
    AVLTreeProto.ascEach = function(callback){
        var that = this;
        traverse(that._rootNode,callback);
        function traverse(treeNode,callback){
            if(!treeNode){
                return;
            }
            else{
                traverse(treeNode._leftChild,callback);
                callback(treeNode.value);
                traverse(treeNode._rightChild,callback);
            }
        }
    }

    //判断当前是否为空树
    AVLTreeProto.isEmpty = function(){
        return !this._rootNode;
    }

    //后序遍历 删除树中所有的节点
    AVLTreeProto.makeEmpty = function(){
        var that = this;
        that._rootNode = makeEmpty(that._rootNode);
        function makeEmpty(treeNode){
            if(!treeNode){
                return;
            }
            else{
                makeEmpty(treeNode._leftChild);
                makeEmpty(treeNode._rightChild);
                treeNode._leftChild = treeNode._rightChild = null;
                treeNode = null;
            }
            return treeNode;
        }
    }

    //后序遍历树 找到失衡节点
    AVLTreeProto._findUnbalanceNode = function(){
        var that = this;
        //动态调整失衡节点
        return findUnbalanceNode(that._rootNode);
        function findUnbalanceNode(treeNode){
            if(!treeNode){
                return null;
            }
            findUnbalanceNode(treeNode._leftChild);
            findUnbalanceNode(treeNode._rightChild);
            //当节点的左右子树的高度绝对值大于一的时候 该节点失衡
            var treeLeftHeight = that._treeHeight(treeNode._leftChild);
            var treeRightHeight = that._treeHeight(treeNode._rightChild);
            var divider = treeLeftHeight - treeRightHeight;
            if(divider > that._unbalanceFactor){
                treeNode._unBalanceDirection = "left";
                return treeNode;
            }
            else if(divider < -that._unbalanceFactor){
                treeNode._unBalanceDirection = "right";
                return treeNode;
            }
            else{
                return null;
            }
        }
    }

    //插入和删除的函数中会调用此方法来判断是否需要调整平衡性
    AVLTreeProto.autoAdjustBalance = function(){
        if(this.autoAdjust){
            this.runAdjustBalance();
        }
    }

    //遍历avl树 调整平衡性
    AVLTreeProto.runAdjustBalance = function(){
        //构造AVL树的平衡性
        var unbalanceTreeNode = this._findUnbalanceNode();
        while(unbalanceTreeNode){
            var adjustedNode = this._adjustBalance();
            this._replacePointer(unbalanceTreeNode,adjustedNode);
            //当avl中所有的结点全部平衡之后 这个值就会返回null 此时循环终止
            unbalanceTreeNode = this._findUnbalanceNode();
        }
    }

    //调整树的节点旋转 构造AVL特性
    AVLTreeProto._adjustBalance = function(){
        var that = this;
        var _unbalanceTreeNode = that._findUnbalanceNode();
        if(_unbalanceTreeNode){
            //当_unbalanceNode返回"left"代表左子树失失衡
            if(_unbalanceTreeNode._unBalanceDirection == "left"){
                _unbalanceTreeNode._unBalanceDirection = "";
                var rotateNode = _unbalanceTreeNode._leftChild;
                var rotateNodeLeftChild  = rotateNode._leftChild;
                var rotateNodeRightChild = rotateNode._rightChild;
                 //LL情况  单次旋转即可平衡
                 if(!rotateNodeRightChild || (!rotateNodeRightChild._leftChild && !rotateNodeRightChild._rightChild)){
                    _unbalanceTreeNode._leftChild = rotateNode._rightChild;
                    rotateNode._rightChild = _unbalanceTreeNode;
                    return rotateNode;
                }
                //LR情况 需要两次旋转才能平衡
                else{
                    rotateNode._rightChild = rotateNodeRightChild._leftChild;
                    rotateNodeRightChild._leftChild = rotateNode;
                    _unbalanceTreeNode._leftChild = rotateNodeRightChild._rightChild;
                    rotateNodeRightChild._rightChild = _unbalanceTreeNode;
                    return rotateNodeRightChild;
                }
            }
            //否则返回true代表右子树失衡
            else{
                _unbalanceTreeNode._unBalanceDirection = "";
                var rotateNode = _unbalanceTreeNode._rightChild;
                var rotateNodeLeftChild  = rotateNode._leftChild;
                var rotateNodeRightChild = rotateNode._rightChild;
                 //RR情况  单次旋转即可平衡
                 if(!rotateNodeLeftChild || (!rotateNodeLeftChild._leftChild && !rotateNodeLeftChild._rightChild)){
                    _unbalanceTreeNode._rightChild = rotateNode._leftChild;
                    rotateNode._leftChild = _unbalanceTreeNode;
                    return rotateNode;
                }
                //RL情况 需要两次旋转才能平衡
                else{
                    rotateNode._leftChild = rotateNodeLeftChild._rightChild;
                    rotateNodeLeftChild._rightChild = rotateNode;
                    _unbalanceTreeNode._rightChild = rotateNodeLeftChild._leftChild;
                    rotateNodeLeftChild._leftChild = _unbalanceTreeNode;
                    return rotateNodeLeftChild;
                }
            }
        }
    }

    AVLTreeProto.getHeight = function(){
        var that = this;
        return that._treeHeight(that._rootNode);
    }

    AVLTreeProto._treeHeight = function(treeNode){
        return getHeight(treeNode);
        function getHeight(treeNode){
            if(!treeNode){
                return 0;
            }
            var leftTreeHeight = getHeight(treeNode._leftChild);
            var rightTreeHeight = getHeight(treeNode._rightChild);

            return Math.max(leftTreeHeight,rightTreeHeight) + 1;
        }
    }

    //这个函数用来对插入的元素进行比较
    //当插入的元素个数大于1时 自动调用该函数
    //当返回大于0的值时候表示 insertElement 比当前的元素key值大
    AVLTreeProto.sort = function(existsElement,insertElement){
        var firstElementValue = 0;
        var secondElementValue = 0;
        if((typeof existsElement == 'number')&&(typeof insertElement == 'number')){
            return insertElement - existsElement;
        }
        else if((existsElement instanceof Object)&&(insertElement instanceof Object)){
            firstElementValue = getValue(JSON.stringify(existsElement));
            secondElementValue = getValue(JSON.stringify(insertElement));
            return secondElementValue - firstElementValue;
        }
        else{
            firstElementValue = String(existsElement);
            secondElementValue = String(insertElement);
            return secondElementValue - firstElementValue;
        }
        function getValue(string){
            if(!string){
                return 0;
            }
            return string.charCodeAt(0) + getValue(string.substring(1));
        }
    }
}).call(this);